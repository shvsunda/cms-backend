package net.javaguides.ems_backend.mapper;

import net.javaguides.ems_backend.dto.CourseDto;
import net.javaguides.ems_backend.entity.Course;

public class CourseMapper {
    public static CourseDto mapToCourseDto(Course course){
        return new CourseDto(
                course.getCourseId(),
                course.getCourseName(),
                course.getCourseCode(),
                course.getDescription()
        );
    }

    public static Course mapToCourse(CourseDto courseDto){
       return new Course(
               courseDto.getCourseId(),
               courseDto.getCourseName(),
               courseDto.getCourseCode(),
               courseDto.getDescription()
       );
    }
}
