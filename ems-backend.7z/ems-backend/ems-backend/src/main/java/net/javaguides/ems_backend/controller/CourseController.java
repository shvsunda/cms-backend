package net.javaguides.ems_backend.controller;

import lombok.AllArgsConstructor;
import net.javaguides.ems_backend.dto.CourseDto;
import net.javaguides.ems_backend.service.CourseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@AllArgsConstructor
@RestController
@RequestMapping("/api/courses")
public class CourseController {
      private CourseService courseService;

      //Build Add Course Rest API
      @PostMapping
      public ResponseEntity<CourseDto> createCourse(@RequestBody CourseDto courseDto){
            CourseDto savedCourse = courseService.createCourse(courseDto);
            return new ResponseEntity<>(savedCourse, HttpStatus.CREATED);
      }

      //Build Get Employee Rest API
      @GetMapping("{id}")
      public ResponseEntity<CourseDto> getCourseById(@PathVariable("id") Long courseId){
           CourseDto courseDto = courseService.getCourseById(courseId);
           return ResponseEntity.ok(courseDto);
      }

      //Build Get All Employees Rest API
      @GetMapping
      public ResponseEntity<List<CourseDto>> getAllCourses(){
            List<CourseDto> courses = courseService.getAllCourses();
            return ResponseEntity.ok(courses);
      }

      //Build Update Employee Rest API
      @PutMapping("{id}")
      public ResponseEntity<CourseDto> updateCourse(@PathVariable("id") Long courseId,@RequestBody CourseDto updatedCourse){
          CourseDto courseDto = courseService.updateCourse(courseId,updatedCourse);
          return ResponseEntity.ok(courseDto);
      }

      //Build Delete Employee Rest API
      @DeleteMapping("{id}")
      public ResponseEntity<String> deleteCourse(@PathVariable("id") Long courseId){
            courseService.deleteCourse(courseId);
            return ResponseEntity.ok("Course removed from list");
      }
}
