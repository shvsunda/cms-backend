package net.javaguides.ems_backend.repository;

import net.javaguides.ems_backend.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course,Long> {

}
